package com.mani.employee.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mani.employee.model.employee;
import com.mani.employee.repository.employeeRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/")

public class Employeecontroller {
	@Autowired
	private employeeRepository employeeRepository;
	@GetMapping("/students")
	public List<employee> getAllStudent(){
		return employeeRepository.findAll();

}
}
