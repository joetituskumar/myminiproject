

    import React, { Component } from 'react';
import employeeservices from './employeeservices';
    
    class Listcomponnets extends Component {

        constructor(){
            super();
            this.state={
                employee :[]
            }
        }

componentDidMount(){
    employeeservices.getemployee().then((res)=>{
        
        this.setState({employee:res.data});
    });
}

        render() {
            return (
                <div>
                    <h2 className="text-center">Employee Details</h2>
                    <div className="row">
                        <table classname="employee">
                       
                            <tbody>
                                <tr>
                                <th>Employee id</th>
                                <th>Employee location</th>
                               
                                
                               
                                
                                </tr>
                            </tbody>
                            <tbody>
                                {
                                    this.state.employee.map(

                                        employee=>
                                        <tr key ={employee.id}>
                                            <td>{employee.id}</td>
                                            
                                            <td>{employee.location}</td>
                                            <td>{employee.employeename}</td>
                                            
                                           
                                            
                                           
                                        </tr>
                                    )
                                }
                            </tbody>


                           
                        </table>
                        </div>
                </div>
            );
        }
    }
    
    export default Listcomponnets;
